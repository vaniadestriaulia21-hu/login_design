package com.vania.designlogin;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvForgotPassword;
    private TextView tvRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        getWindow().setStatusBarColor(Color.rgb(66, 143, 208));
        getWindow().setNavigationBarColor(Color.BLACK);

        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);
        tvRegister = findViewById(R.id.tvRegister);

        btnLogin.setOnClickListener(v -> {
            String username =
                    etUsername.getText().toString().trim();
            String password =
                    etPassword.getText().toString();

            if (username.isEmpty()) {
                etUsername.setError("Username wajib diisi");
                etUsername.requestFocus();
            } else if (password.isEmpty()) {
                etPassword.setError("Password wajib diisi");
                etPassword.requestFocus();
            } else {
                Toast.makeText(
                        MainActivity.this,
                        "Tampilan berhasil. Login belum terhubung ke database.",
                        Toast.LENGTH_LONG
                ).show();
            }
        });

        tvForgotPassword.setOnClickListener(v ->
                Toast.makeText(
                        MainActivity.this,
                        "Fitur lupa password belum tersedia",
                        Toast.LENGTH_SHORT
                ).show()
        );

        tvRegister.setOnClickListener(v ->
                Toast.makeText(
                        MainActivity.this,
                        "Fitur daftar belum tersedia",
                        Toast.LENGTH_SHORT
                ).show()
        );
    }
}
